#!/bin/sh
export LD_LIBRARY_PATH=/opt/apps/com.deepin.youboxclient/files
/opt/apps/com.deepin.youboxclient/files/youboxclient
