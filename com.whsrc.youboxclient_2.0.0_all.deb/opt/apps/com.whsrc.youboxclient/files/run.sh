#!/bin/sh
export LD_LIBRARY_PATH=/opt/apps/com.whsrc.youboxclient/files
/opt/apps/com.whsrc.youboxclient/files/youboxclient
