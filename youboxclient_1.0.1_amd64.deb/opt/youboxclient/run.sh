#!/bin/sh
export LD_LIBRARY_PATH=/home/youboxclient
/opt/youboxclient/youboxclient
