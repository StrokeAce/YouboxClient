#!/bin/sh
export LD_LIBRARY_PATH=/opt/youboxclient
/opt/youboxclient/youboxclient
